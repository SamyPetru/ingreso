function mostrar()
{
    var edad;

    edad=document.getElementById("edad").value;

    if (edad<13 || edad>17) {
        alert("usted es viejo o pendejo");
    }
    


}//FIN DE LA FUNCIÓN