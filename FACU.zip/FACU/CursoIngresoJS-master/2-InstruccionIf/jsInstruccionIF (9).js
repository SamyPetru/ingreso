function mostrar()
{
	var numero;

	numero= Math.floor(Math.random()*(11-1)) + 1;

	alert("el numero solicitado es" + " " + numero);

}//FIN DE LA FUNCIÓN