function mostrar()
{
    var edad;
    var estadocivil;

    edad=document.getElementById("edad").value;
    estadocivil=document.getElementById("estadoCivil").value;

	if (edad<18 && estadocivil!="Soltero") {
        alert ("es pequeño para no ser soltero");
    }
    


}//FIN DE LA FUNCIÓN