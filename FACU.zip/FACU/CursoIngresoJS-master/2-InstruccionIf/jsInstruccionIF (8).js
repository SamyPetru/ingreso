function mostrar()
{
    var edad;
    var estadocivil;

    edad=document.getElementById("edad").value;
    estadocivil=document.getElementById("estadoCivil").value;

    if (edad>=18 && estadocivil=="Soltero") {
        alert ("es soltero y  no es menor señor");
    }


}//FIN DE LA FUNCIÓN