function mostrar()
{
    var edad;

    edad=document.getElementById("edad").value;

    if (edad>=13 && edad<=17) {
        alert ("usted es adolescente, un pito duro");

    }
    



}//FIN DE LA FUNCIÓN