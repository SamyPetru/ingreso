function mostrar()
{
    var edad;

    edad=document.getElementById("edad").value;

    if (edad>=18) {
        alert("usted es un viejo ");
    }
    
}//FIN DE LA FUNCIÓN