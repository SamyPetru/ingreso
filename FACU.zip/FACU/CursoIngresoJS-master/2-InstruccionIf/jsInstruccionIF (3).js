function mostrar()
{
    var edad;

    edad=document.getElementById("edad").value;

    if (edad>=18) {
        alert("usted es un viejo ");
    } 
    else {
        alert("usted es un bebe, ");

    }


}//FIN DE LA FUNCIÓN