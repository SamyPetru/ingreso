function mostrar()
{
	var numero;

	numero= Math.floor(Math.random()*(11-1)) + 1;

	if (numero>=9) {
		alert("excelente, la nota es" + " " + numero);
	}
	else if (numero>=4) {
		alert("la nota es" + " " + numero + " " + "y aprobó");
	}
	else {
		alert("la nota es" + " " + numero + " " + "vamos, la proxima se puede");

	}

}//FIN DE LA FUNCIÓN