function mostrar()
{
    var edad;

    edad=document.getElementById("edad").value;

    if (edad<13) {
        alert ("pendejo ");
    }
    else if (edad>=13 && edad<=17) {
        alert ("pavote");
    }
    else {
        alert ("viejo ");
    }
    

}//FIN DE LA FUNCIÓN