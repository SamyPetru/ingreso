function mostrar()
{
    var numero;
    var contador;

    for(contador=0;contador<11;contador++)
    {
        
        if(contador==1)
        {
            document.write("<br>" + 1);
        }
        if(contador==2)
        {
            document.write("<br>" + 2);
        }
        if(contador==3)
        {
            document.write("<br>" + 3);
        }
        if(contador==4)
        {
            document.write("<br>" + 4);
        }
        if(contador==5)
        {
            document.write("<br>" + 5);
        }
        if(contador==6)
        {
            document.write("<br>" + 6);
        }
        if(contador==7)
        {
            document.write("<br>" + 7);
        }
        if(contador==8)
        {
            document.write("<br>" + 8);
        }
        if(contador==9)
        {
            document.write("<br>" + 9);
        }
        if(contador==10)
        {
            document.write("<br>" + 10);
        }
    }
    
}