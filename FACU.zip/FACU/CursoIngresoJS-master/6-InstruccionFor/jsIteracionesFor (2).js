function mostrar()
{


    
    var repeticiones = prompt("ingrese el número de repeticiones");
    var contador;
    var mensaje;


    repeticiones=parseInt(repeticiones);



    for(contador=0;contador<repeticiones;contador++)
    {
     document.write("<br>" +"hola UTN FRA" +  "<br>" );
    }

    


}