function mostrar()
{
	var contador;

	contador=10;

	while(contador>=1)
	{
		console.log(contador);
		contador--;
	}


}//FIN DE LA FUNCIÓN