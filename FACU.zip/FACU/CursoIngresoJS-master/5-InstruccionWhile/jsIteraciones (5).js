function mostrar()



{
    var sexo;
    var femenino;
    var masculino;

    sexo=prompt("Ingrese su Sexo F o M");
    
    while(sexo!="f" && sexo!="m")
    {
        sexo=prompt("error, ingrese nuevamente");

    }

    document.getElementById("Sexo").value=sexo;

}