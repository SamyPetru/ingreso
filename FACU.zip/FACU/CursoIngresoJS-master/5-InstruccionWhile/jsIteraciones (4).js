function mostrar()



{
	var numero;
	var contador;

	numero=prompt("ingrese numero entre 0 y 9");

	while(numero<0 || numero>9)
	{
		alert("no pertenece al rango");
		numero=prompt("reingrese numero");
		
	}

	document.getElementById("Numero").value=numero;
}