function mostrar()


{
    var numero;
    var contador=0;
    var numeroMaximo;
    var numeroMinimo;
    var respuesta;

    do
    {
        numero=prompt("ingrese un numero");
        numero=parseInt(numero);

        while(contador==0)
        {
            numeroMaximo=numero;
            numeroMinimo=numero;
            contador++;
        }
        if(numero>numeroMaximo)
        {
            numeroMaximo=numero;
        }
        else
        {
            numeroMinimo=numero;
        }


        respuesta=prompt("ingrese si para continuar, cualquier otra tecla para finalizar");
    }while(respuesta=="si");


    document.getElementById("maximo").value=numeroMaximo;
    document.getElementById("minimo").value=numeroMinimo;

}