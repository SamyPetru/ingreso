function mostrar()
{
	var contador;

	contador=1;

	while(contador<=10)
	{
		console.log(contador);
		contador++;
	}




}//FIN DE LA FUNCIÓN