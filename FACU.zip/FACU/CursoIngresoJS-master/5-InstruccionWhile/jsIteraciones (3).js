function mostrar()


{
    var clave;

    clave=prompt("ingrese clave");

    while(clave!="utn750")
    {
        alert("clave incorrecta.");
        clave=prompt("Reingrese clave");
    }
    alert("clave correcta");
}
