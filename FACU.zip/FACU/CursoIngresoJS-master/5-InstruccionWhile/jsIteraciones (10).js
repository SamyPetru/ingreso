function mostrar()


{
    var numero;
    var contador=0;
    var suma=0;
    var positivos=0;
    var negativos=0;
    var respuesta;
    var ceros=0;
    var acumuladorPositivo=0;
    var acumuladorNegativo=0;
    var pares=0;
    var promedioPositivo;
    var promedioNegativo;

    do
    {
        numero=prompt("ingrese numero");
        numero=parseInt(numero);
        while(isNaN(numero))
        {
            numero=prompt("ingrese un numero valido");
        }

        if(numero==0)
        {
            ceros++;
        }
        else
        {
            if(numero<0)
            {
                negativos++;
                acumuladorNegativo=acumuladorNegativo + numero;
            }
            else
            {
                positivos++;
                acumuladorPositivo=acumuladorPositivo + numero;
            }
        }
        if(numero%2==0)
        {
            pares++;
        }



        respuesta=prompt("ingrese si para continuar, cualquier tecla para finalizar");
    }while(respuesta=="si");


    promedioPositivo=acumuladorPositivo/positivos;
    promedioNegativo=acumuladorNegativo/negativos;
    diferencia=acumuladorPositivo+acumuladorNegativo;

    document.write("<br>1. la suma de los negativos es: " + acumuladorNegativo);
    document.write("<br>2. la suma de los positivos es: " + acumuladorPositivo);
    document.write("<br>3. la cantidad de los positivos es: " + positivos);
    document.write("<br>4. la cantidad de los negativos es: " + negativos);
    document.write("<br>5. la cantidad de ceros es: " + ceros);
    document.write("<br>6.la cantidad de numeros pares es: " + pares);
    document.write("<br>7. el promedio de los numeros positivos es: " + promedioPositivo);
    document.write("<br>8. el promedio de los numeros negativos es " + promedioNegativo);
    document.write("<br>9. la diferencia entre positivos y negativos es: " + diferencia);

}


