
function mostrar()
{
    var base;
    var altura;
    var perimetro;

    altura=prompt("ingrese el largo");
    altura=parseInt(altura);

    base=prompt("ingrese la base");
    base=parseInt(base);

    perimetro=base*altura;

    alert("el perimetro del rectángulo es: " + perimetro);



}