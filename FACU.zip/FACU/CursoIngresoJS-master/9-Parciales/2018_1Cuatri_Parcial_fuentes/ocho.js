function mostrar()


{
    var numero;
    var letra;
    var contador=0;
    var respuesta;
    var acumulador=0;
    var contadorpares=0;
    var contadorimpares=0;
    var ceros=0;
    var acumuladorNegativos=0;
    var contadorPositivos=0;

    do
    {
        numero=prompt("ingrese un numero");
        numero=parseInt(numero);
        while(isNaN(numero)|| numero>100 || numero<-100)
        {
            numero=prompt("error, ingrese numero");
        }
        letra=prompt("ingrese una letra");

        if(numero%2==0)
        {
            contadorpares++;
        }
        else
        {
            contadorimpares++;
        }
        if(numero==0)
        {
            ceros++;
        }
        else 
        {
            if(numero<0)
            {
                acumuladorNegativos=acumuladorNegativos+numero;
            }
            else
            {
            acumulador=acumulador+numero;
            contadorPositivos++;

            }
        }
        
        
        
            
        
        if(contador==0)
        {
            numeroMaximo=numero;
            numeroMinimo=numero;
            letraMaxima=letra;
            letraMinima=letra;  
        }
        else
        {
            if(numero>numeroMaximo)
            {
              numeroMaximo=numero;
              letraMaxima=letra;

            }
            else if(numero<numeroMinimo)
            {
                numeroMinimo=numero;
                letraMinima=letra;
            }
           

        }
        contador++;
        respuesta=prompt("ingrese si para continuar, cualquier otra tecla para finalizar");
    }while(respuesta=="si");

    promedio=acumulador/contadorPositivos;

    document.write("<br>la cantidad de numeros pares es: " + contadorpares);
    document.write("<br>la cantidad de numeros impares es: " + contadorimpares);
    document.write("<br>la cantidad de ceros es: " + ceros);
    document.write("<br>el promedio de los positivos es: " + promedio);
    document.write("<br>la suma de los negativos es: " + acumuladorNegativos);
    document.write("<br>el numero maximo es: " + numeroMaximo + " y la letra maxima es: " + letraMaxima);
    document.write("<br>el numero minimo es: " + numeroMinimo + " y la letra minima es: " + letraMinima);


}




/*

{
    var letra;
    var numero;
    var contador;
    var acumulador;
    var respuesta;

    do
    {
        letra=prompt("ingrese una letra");
        numero=prompt("ingrese un numero");
        numero=parseInt(numero);
        while(isNaN(numero) || numero>100 || numero<-100)         //validado
        {
            numero=prompt("ingrese numero entre -100 y 100");
            numero=parseInt(numero);
        }
        
     
        
        
    }while(respuesta=="si");



    document.write("")

    
}





SACAR MIMINO MAXIMO

var contador;
contador=0;
año=...;
color=...,
marca= ...;


while(contador<500)
{
    año
}

    if (contador==0)
    {
        mayoraño=año;               //guardo el año
        mayorcolor=color;          guardo el color
        menoraño=año;
        menormarca=marca;          
    }
    else
    {
        if(año>mayoraño)
        {
            mayor=año;
            mayorcolor=color;
        }
        if(año>menoraño)
        {
            menoraño=año;                   //agregar las variables necesarias de lo que se busca.(variable auxiliar) 
            menorcolor=color;
        }
    }



*/
