function mostrar()

{
    var sexo;
    var nota;
    var contador;
    var acumulador=0;
    var promedio;
    var notaBaja;
    var sexoBajo;
    var contadorVarones=0;


    for(contador=0;contador<5;contador++)
    {
        nota=prompt("ingrese una nota");
        nota=parseInt(nota);
        while(isNaN(nota) || nota<0 || nota>10 )
        {
            nota=prompt("error, ingrese una nota válida");
        }
        sexo=prompt("ingrese un sexo");
        while(sexo!="f" && sexo!="m")
        {
            sexo=prompt("error, ingrese un sexo válido");
        }
        acumulador=acumulador+nota;
        if(contador==0)
        {
            notaBaja=nota;
            sexoBajo=sexo;
        }
        else
        {
            if(nota<notaBaja)
            {
                notaBaja=nota;
                sexoBajo=sexo;
            }
        }
        if(nota>=6)
        {
            contadorVarones++;
        }
    }

    promedio=acumulador/contador;

    alert("el promedio de las notas totales es " + promedio );
    alert("la nota mas baja es: " + notaBaja + " y el sexo de esa persona es: " + sexoBajo);
    alert("la cantidad de varones que su nota superó 6 es: " + contadorVarones);


}