function mostrar()
{
    var marca;
    var peso;
    var temperatura;
    var contador=0;
    var acumulador=0;
    var respuesta;
    var pares=0;
    var marcaPesado;
    var pesoMaximo;
    var pesoMinimo;
    var contadorBajoCero=0;
    var promedio;   


    do
    {
        marca=prompt("ingrese una marca");
        peso=prompt("ingrese un peso");
        peso=parseInt(peso);
        while(isNaN(peso)|| peso<1 || peso>100)
        {
            peso=prompt("error, ingrese peso válido");
            peso=parseInt(peso);
        }
        temperatura=prompt("ingrese temperatura");
        while(isNaN(temperatura) || temperatura<-30 || temperatura>30 )
        {
            temperatura=prompt("error, ingrese temperatura válida");
            temperatura=parseInt(temperatura);
        }


        if(temperatura%2==0)
        {
            pares++;
        }
        if(contador==0)
        {
            marcaPesado=marca;
            pesoMaximo=peso;
            pesoMinimo=peso;
        }
        else
        {
            if(pesoMaximo<peso)
            {
                marcaPesado=marca;
                pesoMaximo=peso;
            } 
            else if(pesoMinimo>peso)
            {
                pesoMinimo=peso;
            }   
        }
        if(temperatura<0)
        {
            contadorBajoCero++;
        }
        acumulador=acumulador+peso;
        contador++;



        respuesta=prompt("ingrese si para continuar, cualquier otra tecla para finalizar");
    }while(respuesta=="si");


    promedio=acumulador/contador;

    document.write("<br>la cantidad de temperaturas pares es: " + pares);
    document.write("<br>la marca del producto mas pesado es: " + marcaPesado);
    document.write("<br>la cantidad de productos bajo cero es: " + contadorBajoCero);
    document.write("<br>promedio del peso de todos los productos: " +promedio);
    document.write("<br>el peso maximo es :" + pesoMaximo + " y el peso minimo es: " + pesoMinimo);

}



