function mostrar()
{
    var planeta;
    var respuesta;

    planeta=prompt("Ingrese un planeta");

    switch(planeta)
    {
        case "mercurio":
        case "venus":
        case "marte":
            respuesta="aca hace mas calor";
            break;
        case "la tierra":
            respuesta="aca vivimos";
            break;
        case "jupiter":
        case "saturno":
        case "urano":
        case "neptuno":
        case "pluton":
            respuesta="aca hace mas frio";
            break;
        default:
            {
                respuesta="no es un planeta valido";
            }
    }
    alert(respuesta);

}
