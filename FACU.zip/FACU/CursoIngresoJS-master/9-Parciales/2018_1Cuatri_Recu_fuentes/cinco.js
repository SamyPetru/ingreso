function mostrar()
{
    var dia;
    var respuesta;

    dia=prompt("Ingrese dia de semana");

    switch(dia)
    {
        case "lunes":
        case "martes":
        case "miercoles":
        case "jueves":
        case "viernes":
            respuesta="a trabajar!";
            break;
        case "sabado":
        case "domingo":
            respuesta="buen finde!";
            break;
        default:
            {
                respuesta="no es un dia valido";
            }
    }
    alert(respuesta);

}
