function mostrar()
{
    var nota;
    var sexo;
    var contador;
    var acumulador=0;
    var promediototal;
    var sexobajo;
    var notabaja;
    var contadorvarones=0;


    for(contador=0;contador<5;contador++)
    {
        nota=prompt("ingrese una nota");
        nota=parseInt(nota);
        while(isNaN(nota) || nota<0 || nota>10)
        {
            nota=prompt("error, ingrese una nota del 0 al 10");
        }
        sexo=prompt("ingrese un sexo");
        while(sexo!="f" && sexo!="m")
        {
            sexo=prompt("error, ingrese sexo f o m");
        }
        acumulador+=nota;
        if(contador==0)
        {
            notabaja=nota;
            sexobajo=sexo;
        }
        if(nota<notabaja)
        {
            notabaja=nota;
            sexobajo=sexo;
        }
        if (nota>=6 && sexo=="m")
        {
            contadorvarones ++;
        }

    }

promediototal=acumulador/contador;

alert("el promedio de las notas totales es " + promediototal );
alert("la nota mas baja es " + notabaja  + " y el sexo es " + sexobajo );
alert("la cantidad de varones que su nota es mayor a 6 son " + contadorvarones );

}
