function mostrar()
{
    var animal;
    var peso;
    var temperatura;
    var respuesta;
    var contador=0;
    var contadorAnimales=0;
    var temperaturasPares=0;
    var animalPesado;
    var temperaturaPesada;
    var acumuladorPeso=0;
    var pesoMinimoBajoCero;
    var pesoMaximoBajoCero;
    var contadorAnimalesBajoCero=0;

    do
    {
        animal=prompt("ingrese un animal");
        peso=prompt("ingrese peso del animal");
        peso=parseInt(peso);
        while(peso<1 || peso>1000)
        {
            peso=prompt("error, ingrese peso válido");
        }
        temperatura=prompt("ingrese temperatura");
        temperatura=parseInt(temperatura);
        while(temperatura<-30 || temperatura>30)
        {
            temperatura=prompt("error, reingrese temperatura válida");
        }
        if(temperatura%2==0)
        {
            temperaturasPares++;
        }
        if(contador==0)
        {
            animalPesado=animal;
            pesoPesado=peso;
            temperaturaPesada=temperatura;
        }
        else if(pesoPesado<peso)
        {
            animalPesado=animal;
            pesoPesado=peso;
            temperaturaPesada=temperatura;
        }
        if(temperatura<0)
        {
            contadorAnimalesBajoCero++;
            while(contador==0)
            {
                pesoMaximoBajoCero=peso;
                pesoMinimoBajoCero=peso;
                contador++;
            }

            if(peso>pesoMaximoBajoCero)
            {
               pesoMaximoBajoCero=peso;
            }
            if(pesoMinimoBajoCero>peso)
            {
                pesoMinimoBajoCero=peso;
            }
        }
        
        acumuladorPeso=acumuladorPeso + peso;
        contadorAnimales++;
        

        respuesta=prompt("ingrese si para continuar o ingrese no para terminar");
    }while(respuesta=="si");

    promedio=acumuladorPeso/contadorAnimales;

    document.write("<br>la cantidad de temperaturas pares son: " + temperaturasPares);
    document.write("<br>el nombre del animal mas pesado es: " + animalPesado + " y la temperatura es: " + temperaturaPesada );
    document.write("<br>la cantidad de animales que viven bajo cero son: " + contadorAnimalesBajoCero);
    document.write("<br>el promedio del peso de todos los animales es: " + promedio);
    document.write("<br>el peso maximo de los animales bajo cero es: " + pesoMaximoBajoCero);
    document.write("<br>el peso minimo de los animales bajo cero es: " + pesoMinimoBajoCero);


}
