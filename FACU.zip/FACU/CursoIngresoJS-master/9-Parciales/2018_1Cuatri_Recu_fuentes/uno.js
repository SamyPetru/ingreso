
function mostrar()
{
    var banda;
    var cancion;

    banda=prompt("hola soy el kaiser, que queres?");
    alert("no faka, estoy trabajando");
    cancion=prompt("algo mas?");
    alert("es que no me vas a convencer ABSOLUTAMENTE con nada");


    

}
