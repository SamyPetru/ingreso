function mostrar()

{
    var numero;
    var letra;
    var contador=0;
    var positivos=0;
    var numeroMaximo;
    var letraMaxima;
    var numeroMinimo;
    var letraMinima;
    var ceros=0;
    var pares=0;
    var impares=0;
    var promedio;
    var negativos=0;
    var respuesta;
    var contadorPositivos=0;


    do
    {
        numero=prompt("ingrese un numero");
        numero=parseInt(numero);
        
        while(isNaN(numero) || numero<-100 || numero>100)
        {
            numero=prompt("error, ingrese numero válido");
        }

        letra=prompt("ingrese una letra");

        if(numero%2==0)
        {
            pares++;
        }
        else
        {
            impares++;
        }
        if(numero==0)
        {
            ceros++;
        }
        if(numero>0)
        {
            positivos=positivos + numero;
            contadorPositivos++;
        }
        else
        {
            negativos=negativos + numero;
        }
        if(contador==0)
        {
            numeroMaximo=numero;
            numeroMinimo=numero;
            letraMaxima=letra;
            letraMinima=letra;
        }
        else
        {
            if(numeroMaximo<numero)
            {
                numeroMaximo=numero;
                letraMaxima=letra;
            }
            else if(numeroMinimo>numero)
            {
                numeroMinimo=numero;
                letraMinima=letra;
            }
        }
        contador++;

        respuesta=prompt("ingrese si para continuar, cualquier otra tecla para finalizar");
    }while(respuesta=="si");

    promedio=positivos/contadorPositivos;


    document.write("<br>la cantidad de numeros pares es: " + pares);
    document.write("<br>la cantidad de numeros impares es: " + impares);
    document.write("<br>la cantidad de ceros es: " + ceros);
    document.write("<br>promedio de los numeros positivos: " + promedio);
    document.write("<br>suma de los numeros negativos: " + negativos);
    document.write("<br>numero maximo: " + numeroMaximo + " y letra maxima: " + letraMaxima);
    document.write("<br>numero minimo: " + numeroMinimo + " y letra minima: " + letraMinima);



}