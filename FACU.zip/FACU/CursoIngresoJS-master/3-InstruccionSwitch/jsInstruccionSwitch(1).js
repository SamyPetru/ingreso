function mostrar()
{
//tomo la edad  
var mesDelAño = document.getElementById('mes').value;

switch(mesDelAño)
{
    case "Enero":
        alert("Que comiences bien el año");
        break;
    case "Febrero":
        alert("Se acaban las vacas");
        break;
    case "Marzo":
        alert("a clases!");
        break;
    case "Abril":
    case "Mayo":
    case "Junio":
        alert("a prepararse la frescolara");
        break;
    case "Julio":
        alert("se vienen las vacaciones");
        break;
    case "Agosto":
    case "Septiembre":
    case "Octubre":
    case "Noviembre":
        alert("ultimo semestre");
        break;
    case "Diciembre":
        alert("felices fiestas");
        break;
}




}//FIN DE LA FUNCIÓN